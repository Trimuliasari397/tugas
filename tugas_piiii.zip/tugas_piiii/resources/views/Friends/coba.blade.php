@extends('layouts.app')

@section('title', 'Coba')

@section('content')
    Urutan ke - {{$ke}}
@endsection



