

<?php $__env->startSection('title', 'Groups'); ?>

<?php $__env->startSection('content'); ?>
<a href="/groups/create" class="btn btn-primary">Tambah Group</a>
<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
  <div class="col-sm-6">
<div class="card" style="width: 18rem;">
  <div class="card-body">
    <a href="/groups/<?php echo e($group['id']); ?>"class="card-title"><?php echo e($group['name']); ?></a>
    <p class="card-text"><?php echo e($group['description']); ?></p>
  <hr>
  <a href="/groups/addmember/<?php echo e($group['id']); ?>" class="btn btn-primary">Tambah Anggota</a>

  <ul class="list-group">
<?php $__currentLoopData = $group->friends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    <?php echo e($friend->nama); ?>

    <form action="/groups/deleteaddmember/<?php echo e($friend->id); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
    <button type="submit" class="bedge  btn btn-danger">X</a>
    </form>
  </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>



  <hr>





    <a href="/groups/<?php echo e($group['id']); ?>/edit" class="btn btn-warning">Edit Group</a>
    <form action="/groups/<?php echo e($group['id']); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <br>
    <button class="btn btn-danger">Delete Group</a>
    </form>
  </div>
</div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
<?php echo e($groups-> links()); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas_piii\resources\views/groups/index.blade.php ENDPATH**/ ?>